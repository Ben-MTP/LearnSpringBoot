package vn.roomdecor.roomdecor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RoomdecorApplicationTests {

	@Test
	void contextLoads() {
	}

}
