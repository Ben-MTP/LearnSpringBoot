package vn.roomdecor.roomdecor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RoomdecorApplication {

	public static void main(String[] args) {
		SpringApplication.run(RoomdecorApplication.class, args);
	}

}
